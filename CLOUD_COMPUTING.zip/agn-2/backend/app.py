from flask import Flask, request, jsonify
import re
import string
import pickle
import os
from sklearn.feature_extraction.text import TfidfVectorizer

app = Flask(__name__)

# Load trained model and vectorizer
model_path = os.path.join(os.path.dirname(__file__), "spam_model.pkl")
vectorizer_path = os.path.join(os.path.dirname(__file__), "vectorizer.pkl")

with open(model_path, "rb") as model_file:
    model = pickle.load(model_file)

with open(vectorizer_path, "rb") as vectorizer_file:
    vectorizer = pickle.load(vectorizer_file)

# Text preprocessing function
def preprocess_text(text):
    text = text.lower()
    text = re.sub(r'\d+', '', text)
    text = text.translate(str.maketrans("", "", string.punctuation))
    text = text.strip()
    return text

@app.route("/predict", methods=["POST"])
def predict():
    data = request.json
    message = data.get("message", "")

    if not message:
        return jsonify({"error": "No message provided"}), 400

    processed_message = preprocess_text(message)
    message_tfidf = vectorizer.transform([processed_message])
    prediction = model.predict(message_tfidf)[0]

    return jsonify({"message": message, "spam": bool(prediction)})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
