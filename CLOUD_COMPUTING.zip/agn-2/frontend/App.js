import { useState } from "react";
import "./App.css";

function App() {
  const [message, setMessage] = useState("");
  const [result, setResult] = useState(null);

  const checkSpam = async () => {
    const response = await fetch("http://localhost:5000/predict", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ message }),
    });

    const data = await response.json();
    setResult(data.spam ? "🚨 Spam Message Detected!" : "✅ This message is NOT spam.");
  };

  return (
    <div className="App">
      <h1>Spam Detector</h1>
      <input 
        type="text" 
        value={message} 
        onChange={(e) => setMessage(e.target.value)} 
        placeholder="Enter SMS here..." 
      />
      <button onClick={checkSpam}>Check</button>
      {result && <p>{result}</p>}
    </div>
  );
}

export default App;
